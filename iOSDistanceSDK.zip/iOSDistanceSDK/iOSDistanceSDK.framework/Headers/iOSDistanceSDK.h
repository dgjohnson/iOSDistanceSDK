//
//  iOSDistanceSDK.h
//  iOSDistanceSDK
//
//  Created by John on 12/20/17.
//  Copyright © 2017 KS Technologies, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iOSDistanceSDK.
FOUNDATION_EXPORT double iOSDistanceSDKVersionNumber;

//! Project version string for iOSDistanceSDK.
FOUNDATION_EXPORT const unsigned char iOSDistanceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOSDistanceSDK/PublicHeader.h>


